package com.example;
public class GreetingControllerTest {

  public void givenName_thenGreetingWithName() {

  }
}
