package com.example.sample;


public class GreetingController {
    public String greeting() {
        return "Lambda is Executed Successfully with Version 1.0.3 !!";
    }
}
