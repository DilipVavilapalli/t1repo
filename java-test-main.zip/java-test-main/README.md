# java-sample
Sample Java Code to Build and push artifacts to S3 and deploy to lambda
